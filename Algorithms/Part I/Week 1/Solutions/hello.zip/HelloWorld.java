/*******************************************
 * Author: Huang
 * Date: 22.01.11
 * Website: https://huang-feiyu.github.io
 * Description: HelloWorld.java for homework
 *******************************************/

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
