select name 
from work_type
order by name asc;