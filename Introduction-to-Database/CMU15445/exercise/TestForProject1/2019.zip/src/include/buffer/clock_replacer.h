//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// clock_replacer.h
//
// Identification: src/include/buffer/clock_replacer.h
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <mutex>  // NOLINT
#include <memory>
#include <unordered_map>

#include "buffer/replacer.h"
#include "common/config.h"

namespace bustub {
  // Circle Linked list
  struct Node {
    Node() {}
    Node(frame_id_t v) : value(v), ref(1) {}
    frame_id_t value;
    bool ref;
    std::shared_ptr<Node> prev;
    std::shared_ptr<Node> next;
  };
/**
 * ClockReplacer implements the clock replacement policy, which approximates the Least Recently Used policy.
 */
class ClockReplacer : public Replacer {
 public:
  /**
   * Create a new ClockReplacer.
   * @param num_pages the maximum number of pages the ClockReplacer will be required to store
   */
  explicit ClockReplacer(size_t num_pages);

  /**
   * Destroys the ClockReplacer.
   */
  ~ClockReplacer() override;

  bool Victim(frame_id_t *frame_id) override;

  void Pin(frame_id_t frame_id) override;

  void Unpin(frame_id_t frame_id) override;

  size_t Size() override;

 private:
  // local variables
  size_t capacity;
  size_t count;
  std::shared_ptr<Node> head_;
  std::shared_ptr<Node> tail_;
  std::unordered_map<frame_id_t, std::shared_ptr<Node>> hashmap_;
  mutable std::mutex latch_;

  // local private methods
  // insert Node at head
  bool Insert(std::shared_ptr<Node> node) {
    if (node == nullptr) {
        return false;
    }
    // add to hashmap_
    hashmap_[node->value] = node;
    // add to first, head is just a non-value node
    node->next = head_->next;
    node->prev = head_;
    head_->next->prev = node;
    head_->next = node;
    node->ref = true;
    count++;
    return true;
  }
  // remove the specific node
  bool Remove(std::shared_ptr<Node> node) {
    if (node == nullptr || hashmap_.count(node->value) == 0) {
        return false;
    }
    node = hashmap_[node->value];
    node->prev->next = node->next;
    node->next->prev = node->prev;
    hashmap_.erase(node->value);
    count--;
    return true;
  }
};

}  // namespace bustub
