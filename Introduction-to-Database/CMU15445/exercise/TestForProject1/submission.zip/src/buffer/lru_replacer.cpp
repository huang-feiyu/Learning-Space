//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_replacer.cpp
//
// Identification: src/buffer/lru_replacer.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_replacer.h"

namespace bustub {

LRUReplacer::LRUReplacer(size_t num_pages) {
    capacity = num_pages;
    count = 0;
    head_ = std::make_shared<Node>(-1);
    tail_ = std::make_shared<Node>(-1);
    head_->next = tail_;
    tail_->prev = head_;
}

LRUReplacer::~LRUReplacer() = default;

bool LRUReplacer::Victim(frame_id_t *frame_id) {
    std::scoped_lock lru_lck(latch_);
    if (count == 0) {
        return false;
    }
    *frame_id = tail_->prev->value;
    return Remove(tail_->prev);
}

void LRUReplacer::Pin(frame_id_t frame_id) {
    std::scoped_lock lru_lck(latch_);
    if (count == 0 || hashmap_.count(frame_id) == 0) {
        return;
    }
    std::shared_ptr<Node> node = hashmap_[frame_id];
    Remove(node);
}

void LRUReplacer::Unpin(frame_id_t frame_id) {
    std::scoped_lock lru_lck(latch_);
    if (hashmap_.count(frame_id) == 1) {
        return;
    }
    if (count == capacity) {
        Remove(tail_->prev);
    }
    std::shared_ptr<Node> node = std::make_shared<Node>(frame_id);
    Insert(node);
}

size_t LRUReplacer::Size() {
    return count;
}

}  // namespace bustub
