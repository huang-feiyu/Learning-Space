//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_replacer.h
//
// Identification: src/include/buffer/lru_replacer.h
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <list>
#include <mutex>  // NOLINT
#include <vector>
#include <unordered_map>
#include <memory>

#include "buffer/replacer.h"
#include "common/config.h"

namespace bustub {
class LRUReplacer : public Replacer {
  struct Node {
    Node() {}
    explicit Node(frame_id_t v) : value(v) {}
    frame_id_t value;
    std::shared_ptr<Node> prev;
    std::shared_ptr<Node> next;
  };

 public:
  explicit LRUReplacer(size_t num_pages);

  ~LRUReplacer() override;

  bool Victim(frame_id_t *frame_id) override;

  void Pin(frame_id_t frame_id) override;

  void Unpin(frame_id_t frame_id) override;

  size_t Size() override;

 private:
  size_t capacity;
  size_t count;
  std::shared_ptr<Node> head_;
  std::shared_ptr<Node> tail_;
  std::unordered_map<frame_id_t, std::shared_ptr<Node>> hashmap_;
  mutable std::mutex latch_;

  bool Insert(std::shared_ptr<Node> node) {
    if (node == nullptr) {
        return false;
    }
    hashmap_[node->value] = node;
    node->next = head_->next;
    node->prev = head_;
    head_->next->prev = node;
    head_->next = node;
    count++;
    return true;
  }
  bool Remove(std::shared_ptr<Node> node) {
    if (node == nullptr || hashmap_.count(node->value) == 0) {
        return false;
    }
    node = hashmap_[node->value];
    node->prev->next = node->next;
    node->next->prev = node->prev;
    hashmap_.erase(node->value);
    count--;
    return true;
  }
};

}  // namespace bustub
