//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager.h"

#include <list>
#include <unordered_map>

namespace bustub {

BufferPoolManager::BufferPoolManager(size_t pool_size, DiskManager *disk_manager, LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  pages_ = new Page[pool_size_];
  replacer_ = new LRUReplacer(pool_size);

  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }
}

BufferPoolManager::~BufferPoolManager() {
  delete[] pages_;
  delete replacer_;
}

Page *BufferPoolManager::FetchPageImpl(page_id_t page_id) {
  std::scoped_lock bpm_slk(latch_);
  if (page_table_.count(page_id) > 0) {
    frame_id_t tmp_frame_id = page_table_[page_id];
    pages_[tmp_frame_id].pin_count_++;
    // remove it from replacer_, so it couldn't be replaced
    replacer_->Pin(tmp_frame_id);
    return &pages_[tmp_frame_id];
  }
  // there is also page that bpm can use
  if (!(free_list_.empty() && replacer_->Size() == 0)) {
    frame_id_t frame_replace_id = 0;
    if (!free_list_.empty()) {
      // get replace page from free_list_
      frame_replace_id = free_list_.front();
      free_list_.pop_front();
    } else if (replacer_->Size() > 0) {
      // get replace page from replacer_
      replacer_->Victim(&frame_replace_id);
      page_table_.erase(pages_[frame_replace_id].page_id_);
      // Data has been modified, write the data to disk
      if (pages_[frame_replace_id].IsDirty()) {
        disk_manager_->WritePage(pages_[frame_replace_id].page_id_, pages_[frame_replace_id].GetData());
      }
    }
    page_table_[page_id] = frame_replace_id;
    pages_[frame_replace_id].page_id_ = page_id;
    pages_[frame_replace_id].pin_count_ = 1;
    pages_[frame_replace_id].is_dirty_ = false;
    disk_manager_->ReadPage(page_id, pages_[frame_replace_id].GetData());
    return &pages_[frame_replace_id];
  }
  // no free page and every replacer pages are pinned
  return nullptr;
}

bool BufferPoolManager::UnpinPageImpl(page_id_t page_id, bool is_dirty) {
  std::scoped_lock bpm_slk(latch_);
  // no such page
  if (page_table_.count(page_id) == 0) {
    return false;
  }
  frame_id_t tmp_frame_id = page_table_[page_id];
  if (pages_[tmp_frame_id].pin_count_ > 0) {
    pages_[tmp_frame_id].pin_count_--;
  }
  if (pages_[tmp_frame_id].pin_count_ == 0) {
    // this page can be replaced
    replacer_->Unpin(tmp_frame_id);
  }
  bool tmp_is_dirty = pages_[tmp_frame_id].is_dirty_;
  if (!tmp_is_dirty) {
    pages_[tmp_frame_id].is_dirty_ = is_dirty;
  }
  return true;
}

bool BufferPoolManager::FlushPageImpl(page_id_t page_id) {
  std::scoped_lock bpm_slk(latch_);
  // no such page
  if (page_table_.count(page_id) == 0) {
    return false;
  }
  frame_id_t tmp_frame_id = page_table_[page_id];
  disk_manager_->WritePage(page_id, pages_[tmp_frame_id].GetData());
  pages_[tmp_frame_id].is_dirty_ = false;
  return true;
}

Page *BufferPoolManager::NewPageImpl(page_id_t *page_id) {
  std::scoped_lock bpm_slk(latch_);
  // no more page
  if (free_list_.empty() && replacer_->Size() == 0) {
    page_id = nullptr;
    return nullptr;
  }
  page_id_t tmp_page_id = disk_manager_->AllocatePage();

  frame_id_t frame_replace_id = 0;
  if (!free_list_.empty()) {
    // get replace page from free_list_
    frame_replace_id = free_list_.front();
    free_list_.pop_front();
  } else if (replacer_->Size() > 0) {
    // get replace page from replacer_
    replacer_->Victim(&frame_replace_id);
    page_table_.erase(pages_[frame_replace_id].page_id_);
    // Data has been modified, write the data to disk
    if (pages_[frame_replace_id].IsDirty()) {
      disk_manager_->WritePage(pages_[frame_replace_id].page_id_, pages_[frame_replace_id].GetData());
    }
  }
  pages_[frame_replace_id].page_id_ = tmp_page_id;
  pages_[frame_replace_id].pin_count_ = 1;
  pages_[frame_replace_id].is_dirty_ = false;
  pages_[frame_replace_id].ResetMemory();
  page_table_[tmp_page_id] = frame_replace_id;
  *page_id = tmp_page_id;
  return &pages_[frame_replace_id];
}

bool BufferPoolManager::DeletePageImpl(page_id_t page_id) {
  std::scoped_lock bpm_slk(latch_);
  // no such page
  if (page_table_.count(page_id) == 0) {
    return true;
  }
  frame_id_t tmp_frame_id = page_table_[page_id];
  // someone is using the page
  if (pages_[tmp_frame_id].pin_count_ != 0) {
    return false;
  }
  // remove from replacer_
  replacer_->Pin(tmp_frame_id);
  // remove from page_table_
  page_table_.erase(page_id);
  // set it to initial state
  pages_[tmp_frame_id].page_id_ = INVALID_PAGE_ID;
  pages_[tmp_frame_id].is_dirty_ = false;
  // add it to free_list_
  free_list_.push_back(tmp_frame_id);
  disk_manager_->DeallocatePage(page_id);
  return true;
}

void BufferPoolManager::FlushAllPagesImpl() {
  auto iter = page_table_.begin();
  while (iter != page_table_.end()) {
    FlushPageImpl(iter->first);
    iter++;
  }
}

}  // namespace bustub
