//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// clock_replacer.cpp
//
// Identification: src/buffer/clock_replacer.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/clock_replacer.h"

namespace bustub {

ClockReplacer::ClockReplacer(size_t num_pages) {
  head_ = std::make_shared<Node>(-1);
  tail_ = std::make_shared<Node>(-1);
  capacity = num_pages;
  count = 0;
  head_->ref = true;
  tail_->ref = true;
  head_->next = tail_;
  tail_->prev = head_;
}

ClockReplacer::~ClockReplacer() = default;

bool ClockReplacer::Victim(frame_id_t *frame_id) {
  std::scoped_lock lru_lck(latch_);
  if (count == 0) {
    return false;
  }
  std::shared_ptr<Node> node = tail_->prev;
  // ref = true
  while (node->ref) {
    node->ref = false;
    node = node->prev;
    if (node->value == -1) {
      break;
    }
  }
  if (node->value != -1) {
    *frame_id = node->value;
    return Remove(node);
  }
  // header node
  *frame_id = tail_->prev->value;
  Remove(tail_->prev);
  return false;
}

void ClockReplacer::Pin(frame_id_t frame_id) {
  std::scoped_lock lru_lck(latch_);
  if (count == 0 || hashmap_.count(frame_id) == 0) {
    return;
  }
  std::shared_ptr<Node> node = hashmap_[frame_id];
  Remove(node);
}

void ClockReplacer::Unpin(frame_id_t frame_id) {
  std::scoped_lock lru_lck(latch_);
  if (hashmap_.count(frame_id) == 1) {
    hashmap_[frame_id]->ref = true;
    return;
  }
  if (count == capacity) {
    frame_id_t tmp;
    Victim(&tmp);
  }
  std::shared_ptr<Node> node = std::make_shared<Node>(frame_id);
  Insert(node);
}

size_t ClockReplacer::Size() { return count; }

}  // namespace bustub
