//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// linear_probe_hash_table.cpp
//
// Identification: src/container/hash/linear_probe_hash_table.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "common/exception.h"
#include "common/logger.h"
#include "common/rid.h"
#include "container/hash/linear_probe_hash_table.h"

namespace bustub {

template <typename KeyType, typename ValueType, typename KeyComparator>
HASH_TABLE_TYPE::LinearProbeHashTable(const std::string &name, BufferPoolManager *buffer_pool_manager,
                                      const KeyComparator &comparator, size_t num_buckets,
                                      HashFunction<KeyType> hash_fn
                                      )
    : name_(name), buffer_pool_manager_(buffer_pool_manager), comparator_(comparator), hash_fn_(std::move(hash_fn)) {
      auto page = buffer_pool_manager_->NewPage(&header_page_id_);
      if (page == nullptr) {
        throw "Out of Memory: LinearProbeHashTable";
      }
      auto header_page = reinterpret_cast<HashTableHeaderPage *>(page->GetData());
      header_page->SetSize(num_buckets);
      appendBuckets(header_page, num_buckets);
    }

/*****************************************************************************
 * SEARCH
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
bool HASH_TABLE_TYPE::GetValue(Transaction *transaction, const KeyType &key, std::vector<ValueType> *result) {
  table_latch_.RLock();
  auto header_page = HeaderPage();
  auto expected_index = this->GetSlotIndex(key);
  auto meet_starting_point = false;
  auto index = expected_index;
  while (true) {
    if (index == expected_index) {
      if (meet_starting_point) break;
      meet_starting_point = true;
    }

    // initialize block_page and block
    auto block_index = index / BLOCK_ARRAY_SIZE;
    auto page = buffer_pool_manager_->FetchPage(header_page->GetBlockPageId(block_index));
    auto block = reinterpret_cast<HashTableBlockPage<KeyType, ValueType, KeyComparator> *>(page->GetData());
    
    // expected offset of k|v pair in this block
    auto data_offset_in_block = index % BLOCK_ARRAY_SIZE;

    // start search
    page->RLatch();
    // there is no such key
    if (!block->IsOccupied(data_offset_in_block)) {
      page->RUnlatch();
      break;
    }
    // sequencial search
    if (block->IsReadable(data_offset_in_block) && comparator_(key, block->KeyAt(data_offset_in_block)) == 0) {
      result->push_back(block->ValueAt(data_offset_in_block));
    }
    page->RUnlatch();
    // move forward
    index = (index + 1) % header_page->GetSize();
  }
  table_latch_.RUnlock();
  if (result->size() > 0) return true;
  else return false;
}
/*****************************************************************************
 * INSERTION
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
bool HASH_TABLE_TYPE::Insert(Transaction *transaction, const KeyType &key, const ValueType &value) {
  table_latch_.RLock();
  auto result = std::vector<ValueType>();
  GetValue(transaction, key, &result);
  // there IS the K|V pair
  if (std::find(result.begin(), result.end(), value) != result.end()) {
    return false;
  }
  auto header_page = HeaderPage();
  auto expected_index = GetSlotIndex(key);
  auto meet_starting_point = false;
  auto index = expected_index;
  while (true) {
    if (index == expected_index) {
      if (meet_starting_point) break;
      meet_starting_point = true;
    }

    // initialize block_page and block
    auto block_index = index / BLOCK_ARRAY_SIZE;
    auto page = buffer_pool_manager_->FetchPage(header_page->GetBlockPageId(block_index));
    auto block = reinterpret_cast<HashTableBlockPage<KeyType, ValueType, KeyComparator> *>(page->GetData());

    // insert and flushing the page if the insert operator successfully
    page->WLatch();
    auto success = block->Insert(index % BLOCK_ARRAY_SIZE, key, value);
    if (success) {
      buffer_pool_manager_->FlushPage(page->GetPageId());
      page->WUnlatch();
      table_latch_.RUnlock();
      return true;
    }
    page->WUnlatch();
    // move forward
    index = (index + 1) % header_page->GetSize();
  }
  table_latch_.RUnlock();
  Resize(header_page->GetSize());
  return Insert(transaction, key, value);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
bool HASH_TABLE_TYPE::Remove(Transaction *transaction, const KeyType &key, const ValueType &value) {
  table_latch_.RLock();
  auto header_page = HeaderPage();
  auto expected_index = GetSlotIndex(key);
  auto meet_starting_point = false;
  auto index = expected_index;
  while (true) {
    if (index == expected_index) {
      if (meet_starting_point) break;
      meet_starting_point = true;
    }

    // initialize block_page and block
    auto block_index = index / BLOCK_ARRAY_SIZE;
    auto page = buffer_pool_manager_->FetchPage(header_page->GetBlockPageId(block_index));
    auto block = reinterpret_cast<HashTableBlockPage<KeyType, ValueType, KeyComparator> *>(page->GetData());
    // expected offset of k|v pair in this block
    auto data_offset_in_block = index % BLOCK_ARRAY_SIZE;

    page->WLatch();
    // there is no such k|v
    if (!block->IsOccupied(data_offset_in_block)) {
      page->WUnlatch();
      break;
    }
    if (block->IsReadable(data_offset_in_block) && comparator_(key, block->KeyAt(data_offset_in_block)) == 0 &&
        value == block->ValueAt(data_offset_in_block)) {
      block->Remove(data_offset_in_block);
      page->WUnlatch();
      table_latch_.RUnlock();
      return true;
    }
    page->WUnlatch();
    index = (index + 1) % header_page->GetSize();
  }
  table_latch_.RUnlock();
  return false;
}

/*****************************************************************************
 * RESIZE
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
void HASH_TABLE_TYPE::Resize(size_t initial_size) {
  table_latch_.WLock();
  auto header_page = HeaderPage();
  auto expected_size = initial_size * 2;
  // double size
  if (header_page->GetSize() < expected_size) {
    auto old_size = header_page->GetSize();
    appendBuckets(header_page, expected_size - old_size);
    // re-organize all k|v pairs
    auto all_old_blocks = std::vector<HashTableBlockPage<KeyType, ValueType, KeyComparator> *>();
    auto all_block_page_ids = std::vector<page_id_t>();
    for (size_t idx = 0; idx < header_page->NumBlocks(); idx++) {
      all_old_blocks.push_back(BlockPage(header_page, idx));
      all_block_page_ids.push_back(header_page->GetBlockPageId(idx));
    }
    header_page->ResetBlocksIndex();
    for (size_t idx = 0; idx < header_page->NumBlocks(); idx++) {
      const auto &block = all_old_blocks[idx];
      for (size_t pair_idx = 0; pair_idx < BLOCK_ARRAY_SIZE; pair_idx++) {
        Insert(nullptr, block->KeyAt(pair_idx), block->ValueAt(pair_idx));
      }
      buffer_pool_manager_->DeletePage(all_block_page_ids[idx]);
    }
  }
  table_latch_.WUnlock();
}

/*****************************************************************************
 * GETSIZE
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
size_t HASH_TABLE_TYPE::GetSize() {
  table_latch_.RLock();
  auto size = HeaderPage()->GetSize();
  table_latch_.RUnlock();
  return size;
}

/*****************************************************************************
 * UTILITIES
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
HashTableHeaderPage *HASH_TABLE_TYPE::HeaderPage() {
  auto page = buffer_pool_manager_->FetchPage(header_page_id_);
  return reinterpret_cast<HashTableHeaderPage *>(page->GetData());
}

template <typename KeyType, typename ValueType, typename KeyComparator>
slot_offset_t HASH_TABLE_TYPE::GetSlotIndex(const KeyType &key) {
  return hash_fn_.GetHash(key) % HeaderPage()->GetSize();
}

template <typename KeyType, typename ValueType, typename KeyComparator>
HashTableBlockPage<KeyType, ValueType, KeyComparator> *HASH_TABLE_TYPE::BlockPage(HashTableHeaderPage *header_page, size_t bucket_ind) {
  auto page = buffer_pool_manager_->FetchPage(header_page->GetBlockPageId(bucket_ind));
  return reinterpret_cast<HashTableBlockPage<KeyType, ValueType, KeyComparator> * >(page->GetData());
}


template <typename KeyType, typename ValueType, typename KeyComparator>
void HASH_TABLE_TYPE::appendBuckets(HashTableHeaderPage *header_page, size_t num_buckets) {
  size_t total_current_buckets = header_page->NumBlocks() * BLOCK_ARRAY_SIZE;
  while (total_current_buckets < num_buckets) {
    page_id_t next_block_id;
    assert(buffer_pool_manager_->NewPage(&next_block_id) != nullptr);
    buffer_pool_manager_->UnpinPage(next_block_id, true);
    buffer_pool_manager_->FlushPage(next_block_id);
    header_page->AddBlockPageId(next_block_id);
    total_current_buckets += BLOCK_ARRAY_SIZE;
  }
}

template class LinearProbeHashTable<int, int, IntComparator>;

template class LinearProbeHashTable<GenericKey<4>, RID, GenericComparator<4>>;
template class LinearProbeHashTable<GenericKey<8>, RID, GenericComparator<8>>;
template class LinearProbeHashTable<GenericKey<16>, RID, GenericComparator<16>>;
template class LinearProbeHashTable<GenericKey<32>, RID, GenericComparator<32>>;
template class LinearProbeHashTable<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
